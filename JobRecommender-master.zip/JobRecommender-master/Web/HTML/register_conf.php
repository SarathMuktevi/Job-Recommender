
<html>
<head >
	<Title>Registration Successful</Title>
	<meta name="keywords" content="Jobs, Recommendation, Linkedin, Content-based Recommendation">
	<meta name="description" content="Job Recommendations based on your Linkedin Profile">
	<meta charset = "UTF-8">
	<meta name="author" content="RaSh">
	<script type="text/javascript" src="http://code.jquery.com/jquery-1.5b1.js"></script>
	<script src= "register.js"></script>
	
	<link rel="stylesheet" type="text/css" href="HomeStyle.css"> 
	<link rel="stylesheet" type="text/css" href="register.css">
	<link rel="stylesheet" type="text/css" href="register_conf.css">
</head>

<body>
	<div id="header">
		<h1 id="page-header">What is the Best job for You?</h1>
	</div>

	<div id="conf-message">
		<p>
			Thank you for registering with Job Recommender. You can visit your profile by logging in.
		</p>
		<a id="login-butt" href="HomePage.php"><p id="login-butt">Back to login</p></a>
	</div>
