<?php 
echo $_POST["username"];
echo "<br/> Logged in <br/>";
echo $_POST["pwd"] ;
?>

