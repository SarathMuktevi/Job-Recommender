# JobRecommender
A content based recommendation engine which suggests jobs which best match your linkedin profile or Resume.

# Idea:
The user's professional summary is broken down into a document of significant terms.
The linkedin job updates is checked everyday to get newly posted jobs.
Their job descriptions are broken down into a document of significant words. 
A combined set of profiles is created and similarity between the user profile and the job profile is calculated.
Then the most similar job profile is listed to the user via mail or on his profile page.


